# 4.0 Embeds

Adding videos, music!

Make sure that you have installed the [gitbook-plugin-video](https://www.npmjs.com/package/gitbook-plugin-video).

If adding videos, 

{% video %}https://www.youtube.com/watch?v=A_gNnNs0MxA{% endvideo %}


![](2020-11-23-11-41-21.png)

***Note***:
The original plugin only supports youtube and vimeo videos, but you can open `node_modules/gitbook-plugin-video/index.js` and then do any thing you want. After the modification, you can append videos that hosted in Google Drive, Baidu.....

