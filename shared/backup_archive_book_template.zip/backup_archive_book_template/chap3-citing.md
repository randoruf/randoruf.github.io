# 3.0 Citing Others' Work

If you want to append the reference, like this RRT-Connect {{"kuffner2000rrt"|cite}}. 

`{{"kuffner2000rrt"|cite}}`