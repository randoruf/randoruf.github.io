# 2.2 Code Block 

 To display the code and hightlight the code block. 

```python
def fibonacci(int: n) -> int: 
    if n == 1:
        return 0 
    elif n == 2:
        return 1 
    else:
        return fibonacci(n-1) + fibonacci(n-2)
```