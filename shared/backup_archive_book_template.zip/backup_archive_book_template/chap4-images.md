# 4.0 Use Visual Studio Code like Typora 

安装 **Paste Image** 的插件之后， 可以实现和 Typora 完全一样的功能呢！


首先是如何截图？

如果使用 Windows 10 不用担心， 因为 `Windows key + Shift + S` 可以直接把图片复制到 Clipboard. 

如果使用 Mac 就麻烦一点， 你需要同时按住 `Control + Shift + Command  + 4` 来让截图复制到 Clipboard。 

如果你觉得麻烦，就进入设置， 把两个选项换一下顺序。 让 `Shift + Command + 4` 默认是复制到 Clipboard. 

然后 [Paste Image](https://marketplace.visualstudio.com/items?itemName=mushan.vscode-paste-image) 的 Visual Studio Code 的插件， 可以粘贴 `Option + Command + V`. 正常情况下是 `Command + V` 粘贴。



如果你想改变图片的大小

```html
<img src="????.png" style="zoom:25%;" />
```

如果我有时间会对插件进行修改， 让他默认输出这种格式。