# Book Template

Write your book title here.

This a template for Gtibook. The MathJax(pro) has been included. 

And about how to use Gitbook <https://yangjh.oschina.io/gitbook/>

Don't forget to run 


```shell
gitbook build . (path)
```

to build the static html files in the `(path)` directory. This is important, as it allows you to publish your book on the Internet. 

I will run 

```shell
gitbook build . site
```



If you want to use the gitbook locally, you can run the GitBook server which will watch your files as you work and server them on `localhost:4000`.

```bash
gitbook serve
```





## Troubleshooting

https://gchq.github.io/stroom-docs/dev-guide/gitbook.html

### I get an error when trying to run `gitbook serve`

If you see `Errpr: watch /path/to/stroom ENOSPC` then run the following: `echo fs.inotify.max_user_watches=524288 | sudo tee -a /etc/sysctl.conf && sudo sysctl -p`

### Links don't work when I load `_book/index.html`

It won't, because [CORS](https://en.wikipedia.org/wiki/Cross-origin_resource_sharing) is not and cannot be enabled when viewing local files. You need to run `gitbook serve` or if you really don't want to do that try `cd _book && python -m SimpleHTTPServer`.



或者可以尝试。

https://blog.csdn.net/demon119/article/details/107043333/

* 找到gitbook文件夹，进入找到theme.js文件
* 打开theme.js文件，然后通过搜索找到if(m)for(n.handler&&，把**m**修改为**false，**保存文件 ，就可以实现html跳转了
  * 但此时的搜索功能就不能使用了。

