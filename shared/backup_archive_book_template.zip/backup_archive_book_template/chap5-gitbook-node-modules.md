# 5.0 Gitbook Node Modules 

By default, the node modules will not be uploaded to the github repository as the `.gitignore` file has the following content. 

```
.DS_Store
node_modules/
_book/
```

But this template contains the npm package for the sake for convenience. Look at the `node_modules.zip` (I made some changes to the original packages, so it is impossible to restore the developement environment while just listing the packages I used).

The packages that I used should be listed in the file `book.json`. 

 - `gitbook-plugin-mathjax-pro`
 - `gitbook-plugin-prism`
 - `gitbook-plugin-prism-themes`
 - `gitbook-plugin-bibtex-indexed-cite`
 - `gitbook-plugin-video`

Unzip `node_modules.zip` it if you want to create a new book. 


---

If you accidently push those files, you can first delete all of them and then the `.gitignore` should work.  


---

For example, delete `.DS_Store` files and ignore them in all afterward commits. 

```shell
find . -name .DS_Store -print0 | xargs -0 git rm -f --ignore-unmatch
```

`find . -name .DS_Store -print0 ` will find all files has the name `.DS_Store`. 

` | ` will pass the output to the screen to `xargs`. 

Finally, `echo .DS_Store >> .gitignore` and push to Github repository. 

---

For example, delete `_book` directory. You need to explicitly remove those directory if you don't want to track them any more. Otherwise, Git will still track them even though you have add `_book/` to the `gitignore` file. 

`echo "_book/" >> .gitignore`

`git rm -r --cached _book`
 
