# Summary

### Introduction 
* [Book Template](README.md)

### For Engineering Notes
* [Math Equation](/chap2-math-equation.md)
* [Code Block](chap2-code-block.md)
  
### For Researching 
* [Citation](chap3-citing.md)

### Markdown Skills
* [Videos](chap4-embeds.md)
* [Images](chap4-images.md)
* [Links](chap4-links.md)
* [Tables](chap4-table.md)

### About Gitbook
* [summary.md](chap5-summary-file.md)
* [New Plugins](chap5-new-plugin.md)

### Reference
* [Reference](References.md)


