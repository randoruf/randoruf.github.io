# 2.1 Math Equation 

Use the Mathjax package to display math formula in Latex syntax. 

$$
f(x) = \int_{-\infty}^{\infty} 
    \hat f(\xi)\, e^{2 \pi i \xi x}
    \, d\xi
$$

Note that, Visual Studio Code supports **[Snippets](https://code.visualstudio.com/docs/editor/userdefinedsnippets)** and automatic completion for Latex math equation. It can save your time without typing the same expression again and again. 

Now it is time to change to **Visual Studio Code** from Typora. 



