# 5.0 How to use `summary.md`

The first thing is the naming convention. 

The structure looks like `Part -> Chapter`

Why is that?

Because it is for you to re-arrange the order of each file, you just need to specify which chapter of a file. 

Hence, there is one level inside each part (looks like `2.1`, `2.2` and **`2.1.1` is not allowed**). 


If you want to add new content to the `summary.md`, you could type `/` to inform Visual Stuido Code to show related files, and then delete `/` after selecting files. 

在`summary.md`中， 如果你输入`/`是可以让 VS Code 显示此目录下的相关文件的。这样就可以很方便地添加新的章节， 记得之后删除掉就可以了。 
