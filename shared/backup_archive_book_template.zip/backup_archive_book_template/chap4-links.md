# 4.0 Links

Paste link on selected text (the **Markdown All in One** is installed).

![](2020-11-19-20-56-49.png)
![](2020-11-19-20-57-34.png)

