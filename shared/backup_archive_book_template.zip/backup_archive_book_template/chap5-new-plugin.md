# Adding New Plugins

安装插件并没有什么难度， 网上一堆教程。

不过往往安装完之后， 都需要安装 


```shell
gitbook install ./
```

建议使用 VS Code, 然后打开 Terminal ，在里面的体验甚至比 iTerm 更好！