# 4.0 Add Table in Markdown 

It is easier for you to create tables now!

With **Markdown All in One** plugin, 

但不要按照官方的说法使用 `option + shift + F`,  会与 Mac 的键盘有冲突。

![](2020-11-19-21-09-14.png)

对着你的不完整表格， **右键，然后点击 "Format Document"**

<img src="image-20201121214933249.png" alt="image-20201121214933249" style="zoom: 50%;" />

